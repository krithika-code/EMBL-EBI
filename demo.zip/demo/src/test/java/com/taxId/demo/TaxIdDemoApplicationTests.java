package com.taxId.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxIdDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
