package com.taxId.demo.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.stereotype.Controller;
import com.taxId.demo.model.*;

@Controller
public class TaxIdController {
	private final Log logger = LogFactory.getLog(getClass());

	@GetMapping("/ping")
	public ResponseEntity<String> serviceBasic() {
		return ResponseEntity.status(HttpStatus.OK).body("OK");
	}

	@RequestMapping(value = "/taxId", method = RequestMethod.GET)
	public ModelAndView taxId() {
		return new ModelAndView("taxId", "command", new Model());
	}

	@RequestMapping(value = "/result", method = RequestMethod.POST)
	public String result(@ModelAttribute("SpringWeb") Model model1, ModelMap model) {
		model.addAttribute("id", model1.getId());
		return "result";
	}
}
